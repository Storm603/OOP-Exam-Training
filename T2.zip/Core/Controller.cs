﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Heroes.Core.Contracts;
using Heroes.Models.Contracts;
using Heroes.Models.Heroes;
using Heroes.Models.Map;
using Heroes.Models.Weapons;
using Heroes.Repositories;

namespace Heroes.Core
{
    public class Controller : IController
    {
        public Controller()
        {
            heroes = new HeroRepository();
            weapons = new WeaponRepository();
        }

        private HeroRepository heroes;
        private WeaponRepository weapons;
        public string CreateWeapon(string type, string name, int durability)
        {
            IWeapon weapon = weapons.FindByName(name);

            if (weapon != null)
            {
                throw new InvalidOperationException($"The weapon {name} already exists.");
            }

            if (type != "Claymore" && type != "Mace")
            {
                throw new InvalidOperationException("Invalid weapon type.");
            }

            if (type == "Claymore")
            {
                weapon = new Claymore(name, durability);
            }
            else
            {
                weapon = new Mace(name, durability);
            }

            weapons.Add(weapon);

            return $"A {type.ToLower()} {name} is added to the collection.";
        }

        public string CreateHero(string type, string name, int health, int armour)
        {
            IHero hero = heroes.FindByName(name);

            if (hero != null)
            {
                throw new ArgumentException($"The hero {name} already exists.");
            }

            if (type != "Knight" && type != "Barbarian")
            {
                throw new InvalidOperationException("Invalid hero type.");
            }

            string message;

            if (type == "Knight")
            {
                hero = new Knight(name, health, armour);
                message = $"Successfully added Sir {name} to the collection.";
            }
            else
            {
                hero = new Barbarian(name, health, armour);
                message = $"Successfully added Barbarian {name} to the collection.";
            }

            heroes.Add(hero);

            return message;
        }

        public string AddWeaponToHero(string weaponName, string heroName)
        {
            IHero hero = heroes.FindByName(heroName);
            IWeapon weapon = weapons.FindByName(weaponName);

            if (hero == null)
            {
                throw new InvalidOperationException($"Hero {heroName} does not exist.");
            }

            if (weapon == null)
            {
                throw new InvalidOperationException($"Weapon {weaponName} does not exist.");
            }

            if (hero.Weapon != null)
            {
                throw new InvalidOperationException($"Hero {weaponName} is well-armed.");
            }

            hero.AddWeapon(weapon);
            weapons.Remove(weapon);
            return $"Hero {heroName} can participate in battle using a {weapon.GetType().Name.ToLower()}.";
        }

        public string StartBattle()
        {
            Map map = new Map();

            ICollection<IHero> heros = heroes.Models.Where(x => x.IsAlive && x.Weapon != null).ToList();

            return map.Fight(heros);
        }

        public string HeroReport()
        {
            StringBuilder sb = new StringBuilder();

            foreach (IHero hero in heroes.Models.OrderBy(x => x.GetType().Name).ThenByDescending(x => x.Health).ThenBy(x => x.Name))
            {
                sb.AppendLine($"{hero.GetType().Name}: {hero.Name}");
                sb.AppendLine($"--Health: {hero.Health}");
                sb.AppendLine($"--Armour: {hero.Armour}");
                sb.AppendLine("--Weapon: " + (hero.Weapon == null ? "Unarmed" : $"{hero.Weapon.Name}"));
            }

            return sb.ToString().Trim();
        }
    }
}
