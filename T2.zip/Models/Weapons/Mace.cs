﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace Heroes.Models.Weapons
{
    public class Mace : Weapon
    {
        public Mace(string name, int durability) : base(name, durability)
        {
            weaponDamage = 25;
        }
        
        public override int DoDamage()
        {
            if (Durability == 0)
            {
                return 0;
            }
            Durability -= 1;

            return weaponDamage;
        }
    }
}
