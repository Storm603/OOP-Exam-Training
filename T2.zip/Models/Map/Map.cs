﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Heroes.Models.Contracts;
using Heroes.Models.Heroes;

namespace Heroes.Models.Map
{
    public class Map : IMap
    {
        public string Fight(ICollection<IHero> players)
        {
            List<IHero> knights = players.Where(x => x.GetType().Name == "Knight" && x.IsAlive).ToList();
            List<IHero> barbarians = players.Where(x => x.GetType().Name == "Barbarian" && x.IsAlive).ToList();

            while (true)
            {
                foreach (IHero knight in knights.Where(x => x.IsAlive))
                {
                    foreach (IHero barbarian in barbarians.Where(x => x.IsAlive))
                    {
                        if (barbarian.IsAlive)
                        {
                            barbarian.TakeDamage(knight.Weapon.DoDamage());
                        }
                    }
                }

                if (!barbarians.Any(x => x.IsAlive))
                {
                    break;
                }

                foreach (IHero barbarian in barbarians.Where(x => x.IsAlive))
                {
                    foreach (IHero knight in knights.Where(x => x.IsAlive))
                    {
                        if (knight.IsAlive)
                        {
                            knight.TakeDamage(barbarian.Weapon.DoDamage());
                        }
                    }
                }

                if (knights.All(x => !x.IsAlive))
                {
                    break;
                }
            }

            if (!barbarians.Any(x => x.IsAlive))
            {
                return $"The knights took {knights.Count(x => !x.IsAlive)} casualties but won the battle.";
            }

            return $"The barbarians took {knights.Count(x => !x.IsAlive)} casualties but won the battle.";
        }
    }
}
