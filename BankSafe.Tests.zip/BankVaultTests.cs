using NUnit.Framework;
using System;
using System.Linq;

namespace BankSafe.Tests
{
    public class BankVaultTests
    {
        [SetUp]
        public void Setup()
        {
            
        }

        [Test]
        public void TestAdding()
        {
            // 1
            BankVault vault = new BankVault();

            Item item = new Item("name", "id");

            Assert.Throws<ArgumentException>(() => vault.AddItem("C5", item));

            // 2

            vault.AddItem("A1", item);

            Item item1 = new Item("name1", "id1");
            
            Assert.Throws<ArgumentException>( () => vault.AddItem("A1", item1));

            // 3
            
            Item item2 = new Item("name2", "id2");
            vault.AddItem("A2", item2);
            Assert.Throws<ArgumentException>(() => vault.AddItem("A2", item2));

            // 4

            Item item3 = new Item("name3", "id3");

            string result = vault.AddItem("A3", item3);
            Assert.That(result == "Item:id3 saved successfully!");

            // 5

            Assert.That(vault.VaultCells["A3"] == item3);

        }

        [Test]
        public void RemoveItemTest()
        {
            // 1
            BankVault vault = new BankVault();

            Item item = new Item("name", "id");

            Assert.Throws<ArgumentException>(() => vault.RemoveItem("C5", item));

            //2

            Assert.Throws<ArgumentException>(() => vault.RemoveItem("C4", item));

            //3

            vault.AddItem("A1", item);
            string result = vault.RemoveItem("A1", item);
            Assert.That(result == "Remove item:id successfully!");

            //4

            Assert.That(vault.VaultCells["A1"] == null);
        }
    }
}