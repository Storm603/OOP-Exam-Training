﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Easter.Core.Contracts;
using Easter.Models.Bunnies;
using Easter.Models.Bunnies.Contracts;
using Easter.Models.Dyes;
using Easter.Models.Dyes.Contracts;
using Easter.Models.Eggs;
using Easter.Models.Eggs.Contracts;
using Easter.Repositories;

namespace Easter.Core
{
    public class Controller : IController
    {
        public Controller()
        {
            bunies = new BunnyRepository();
            eggs = new EggRepository();
            workshop = new Workshop();
        }
        private BunnyRepository bunies;
        private EggRepository eggs;
        private Workshop workshop;
        public string AddBunny(string bunnyType, string bunnyName)
        {
            IBunny bunny;
            if (bunnyType == "HappyBunny")
            {
                bunny = new HappyBunny(bunnyName);
            }
            else if (bunnyType == "SleepyBunny")
            {
                bunny = new SleepyBunny(bunnyName);
            }
            else
            {
                throw new InvalidOperationException(Utilities.Messages.ExceptionMessages.InvalidBunnyType);
            }

            bunies.Add(bunny);
            return string.Format(Utilities.Messages.OutputMessages.BunnyAdded, bunnyType, bunnyName);
        }

        public string AddDyeToBunny(string bunnyName, int power)
        {
            IDye dye = new Dye(power);
            IBunny bunny = bunies.FindByName(bunnyName);
            if (bunny == null)
            {
                throw new InvalidOperationException(Utilities.Messages.ExceptionMessages.InexistentBunny);
            }
            bunny.AddDye(dye);
            return string.Format(Utilities.Messages.OutputMessages.DyeAdded, power, bunnyName);
        }

        public string AddEgg(string eggName, int energyRequired)
        {
            IEgg egg = new Egg(eggName, energyRequired);

            eggs.Add(egg);
            return String.Format(Utilities.Messages.OutputMessages.EggAdded, eggName);
        }

        public string ColorEgg(string eggName)
        {
            IEgg egg = eggs.FindByName(eggName);

            bool readyOnes = bunies.Models.Any(x => x.Energy >= 50);

            if (!readyOnes)
            {
                throw new InvalidOperationException(Utilities.Messages.ExceptionMessages.BunniesNotReady);
            }

            List<IBunny> bunnies = bunies.Models.Where(x => x.Energy >= 50).OrderByDescending(x => x.Energy).ToList();

            foreach (IBunny bunny in bunnies)
            {
                workshop.Color(egg, bunny);
                if (bunny.Energy == 0)
                {
                    bunies.Remove(bunny);
                }

                if (egg.IsDone())
                {
                    return string.Format(Utilities.Messages.OutputMessages.EggIsDone, eggName);
                }
            }

            return string.Format(Utilities.Messages.OutputMessages.EggIsNotDone, eggName);
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{eggs.Models.Count(x => x.IsDone())} eggs are done!");
            sb.AppendLine("Bunnies info:");
            foreach (IBunny bunny in bunies.Models)
            {
                sb.AppendLine($"Name: {bunny.Name}");
                sb.AppendLine($"Energy: {bunny.Energy}");
                sb.AppendLine($"Dyes: {bunny.Dyes.Count(x => x.Power > 0)} not finished");
            }

            return sb.ToString().TrimEnd();
        }
    }
}
