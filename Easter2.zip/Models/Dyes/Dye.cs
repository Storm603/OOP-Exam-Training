﻿using System;
using System.Collections.Generic;
using System.Text;
using Easter.Models.Dyes.Contracts;

namespace Easter.Models.Dyes
{
    public class Dye : IDye
    {
        public Dye(int power)
        {
            Power = power;
        }
        private int power;

        public int Power
        {
            get => power;
            private set
            {
                if (value < 0)
                {
                    power = 0;
                    return;
                }

                power = value;
            }
        }

        public void Use()
        {
            Power -= 10;
        }

        public bool IsFinished()
        {
            if (power == 0)
            {
                return true;
            }

            return false;
        }
    }
}
