﻿using System;
using NUnit.Framework;

namespace Gyms.Tests
{
    public class GymsTests
    {
        [Test]
        public void Test_Bad_Gym_Creation()
        {
            Gym athl = null;
            Assert.Throws<ArgumentNullException>(() => athl = new Gym("", 20));
            Assert.Throws<ArgumentNullException>(() => athl = new Gym(null, 20));
        }

        [Test]
        public void Test_Count_Increase()
        {
            Gym gym = new Gym("Name", 20);

            for (int i = 0; i < 15; i++)
            {
                gym.AddAthlete(new Athlete(i.ToString()));
            }

            Assert.That(gym.Count == 15);
        }

        [Test]
        public void Test_Bad_Gym_Capacity()
        {
            Assert.Throws<ArgumentException>(() => new Gym("asfs", -1));
        }

        [Test]
        public void Test_Adding_Athlete_Successfully()
        {
            Gym gym = new Gym("name", 20);
            Athlete athlete = new Athlete("name");

            gym.AddAthlete(athlete);

            Assert.That(gym.Count == 1);
        }

        [Test]
        public void Test_Capacity()
        {
            Gym gym = new Gym("name", 20);
            Assert.That(gym.Capacity == 20);
        }

        [Test]
        public void Test_Adding_Athlete_Unsuccessfully()
        {
            Gym gym = new Gym("name", 2);
            Athlete athlete = new Athlete("name");

           gym.AddAthlete(athlete);
           gym.AddAthlete(athlete);
           Assert.Throws<InvalidOperationException>(() => gym.AddAthlete(athlete));
        }

        [Test]
        public void Test_Removing_Athlete_Successfully()
        {
            Gym gym = new Gym("name", 20);
            Athlete athlete = new Athlete("name");
            Athlete athletse = new Athlete("name1");

            gym.AddAthlete(athlete);
            gym.AddAthlete(athletse);
            gym.RemoveAthlete(athlete.FullName);

            Assert.That(gym.Count == 1);
        }

        [Test]
        public void Test_Removing_Athlete_Unsuccessfully()
        {
            Gym gym = new Gym("name", 20);
            Athlete athlete = new Athlete("name");
            Athlete athletse = new Athlete("name1");

            gym.AddAthlete(athlete);
            gym.AddAthlete(athletse);

            Assert.Throws<InvalidOperationException>(() => gym.RemoveAthlete("name2"));
        }

        [Test]
        public void Test_Injuring_Athlete_Successfully()
        {
            Gym gym = new Gym("name", 20);
            Athlete athlete = new Athlete("name");

            gym.AddAthlete(athlete);
            gym.InjureAthlete(athlete.FullName);

            Assert.True(athlete.IsInjured);
        }
        
        [Test]
        public void Test_Injuring_Athlete_Unsuccessfully()
        {
            Gym gym = new Gym("name", 20);
            
            Assert.Throws<InvalidOperationException>(() => gym.InjureAthlete("asdfasd"));
        }

        [Test]
        public void Test_Report1()
        {
            Gym gym = new Gym("name", 20);
            Athlete athlete1 = new Athlete("nam1");

            gym.AddAthlete(athlete1);

            string report = gym.Report();

            Assert.That(report.Contains(gym.Name));
        }
        [Test]
        public void Test_Report2()
        {
            Gym gym = new Gym("name", 20);
            Athlete athlete1 = new Athlete("nam1");

            gym.AddAthlete(athlete1);
            gym.RemoveAthlete(athlete1.FullName);

            string report = gym.Report();

            Assert.That(gym.Count == 0);
        }
    }
}
