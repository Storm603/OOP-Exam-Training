﻿using NUnit.Framework;

namespace Robots.Tests
{
    using System;

    public class RobotsTests
    {
        [Test]
        public void Test_Capacity_Correct()
        {
            Robot robot = new Robot("name", 100);
            RobotManager manager = new RobotManager(2);

            manager.Add(robot);

            Assert.That(manager.Count == 1);
        }

        [Test]
        public void Test_Capacity_Incorrect()
        {
            Assert.Throws<ArgumentException>(() => new RobotManager(-1));
        }

        [Test]
        public void Test_Capacity()
        {
            RobotManager manager = new RobotManager(2);

            Assert.That(manager.Capacity == 2);
        }

        [Test]
        public void Test_Add_Correct()
        {
            RobotManager manager = new RobotManager(3);

            manager.Add(new Robot("name", 100));
            manager.Add(new Robot("nam1e", 100));

            Assert.That(manager.Count == 2);
        }

        [Test]
        public void Test_Add_Capacity_Problem()
        {
            RobotManager manager = new RobotManager(2);

            manager.Add(new Robot("name", 100));
            manager.Add(new Robot("name1", 100));

            Assert.Throws<InvalidOperationException>(() => manager.Add(new Robot("name2", 100)));
        }

        [Test]
        public void Test_Add_Name_Problem()
        {
            RobotManager manager = new RobotManager(2);

            manager.Add(new Robot("name", 100));

            Assert.Throws<InvalidOperationException>(() => manager.Add(new Robot("name", 100)));
        }

        [Test]
        public void Test_Remove_Correct()
        {
            RobotManager manager = new RobotManager(3);

            manager.Add(new Robot("name", 100));
            manager.Add(new Robot("nam1e", 100));
            manager.Remove("nam1e");

            Assert.That(manager.Count == 1);
        }

        [Test]
        public void Test_Remove_Null()
        {
            RobotManager manager = new RobotManager(3);

            manager.Add(new Robot("name", 100));
            manager.Add(new Robot("nam1e", 100));

            Assert.Throws<InvalidOperationException>(() => manager.Remove("namsdasda1e"));
        }

        [Test]
        public void Test_Work_Null()
        {
            RobotManager manager = new RobotManager(3);

            manager.Add(new Robot("name", 100));
            manager.Add(new Robot("nam1e", 100));

            Assert.Throws<InvalidOperationException>(() => manager.Work("namsdasda1e", "clean", 50));
        }

        [Test]
        public void Test_Work_Battery_Issues()
        {
            RobotManager manager = new RobotManager(3);

            manager.Add(new Robot("name", 100));
            manager.Add(new Robot("nam1e", 100));

            Assert.Throws<InvalidOperationException>(() => manager.Work("name", "tidy", 101));
        }

        [Test]
        public void Test_Work_Correct()
        {
            RobotManager manager = new RobotManager(3);
            Robot robot = new Robot("name", 100);
            manager.Add(robot);
            manager.Work("name", "tidy", 50);

            Assert.That(robot.Battery == 50);
        }

        [Test]
        public void Test_Charge_Null()
        {
            RobotManager manager = new RobotManager(3);
            Robot robot = new Robot("name", 100);
            manager.Add(robot);

            Assert.Throws<InvalidOperationException>(() => manager.Charge("namsadase"));
        }

        [Test]
        public void Test_Charge_Correct()
        {
            RobotManager manager = new RobotManager(3);
            Robot robot = new Robot("name", 100);
            manager.Add(robot);
            manager.Work("name", "tidyup", 70);
            manager.Charge("name");

            Assert.That(robot.Battery == 100);
        }
    }
}
