﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Gym.Models.Athletes.Contracts;
using Gym.Models.Equipment.Contracts;
using Gym.Models.Gyms.Contracts;
using Gym.Repositories.Contracts;

namespace Gym.Models.Gyms
{
    public abstract class Gym : IGym, IRepository<IEquipment>
    {
        public Gym(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
            Equipment = new List<IEquipment>();
            Athletes = new List<IAthlete>();
            models = new List<IEquipment>();
        }

        private string name;
        public string Name
        {
            get { return name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(Utilities.Messages.ExceptionMessages.InvalidGymName);
                }

                name = value;
            }
        }

        private int capacity;
        public int Capacity
        {
            get { return capacity; }
            private set { capacity = value; }
        }

        public double EquipmentWeight => Equipment.Sum(x => x.Weight);
        public ICollection<IEquipment> Equipment { get; }
        public ICollection<IAthlete> Athletes { get; }

        private List<IEquipment> models;
        public IReadOnlyCollection<IEquipment> Models => models.AsReadOnly();

        public void AddAthlete(IAthlete athlete)
        {
            if (Athletes.Count == Capacity)
            {
                throw new InvalidOperationException(Utilities.Messages.ExceptionMessages.NotEnoughSize);
            }

            Athletes.Add(athlete);
        }

        public bool RemoveAthlete(IAthlete athlete)
        {
            bool result = Athletes.Remove(athlete);
            return result;
        }

        public void AddEquipment(IEquipment equipment)
        {
            Equipment.Add(equipment);
        }

        public void Exercise()
        {
            foreach (IAthlete athlete in Athletes)
            {
                athlete.Exercise();
            }
        }

        public string GymInfo()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"{Name} is a {this.GetType().Name}:");
            if (Athletes.Count == 0)
            {
                sb.AppendLine("No athletes");
            }
            else
            {
                sb.AppendLine($"Athletes: {string.Join(", ", Athletes)}");
            }

            sb.AppendLine($"Equipment total count: {Equipment.Count}");
            sb.AppendLine($"Equipment total weight: {EquipmentWeight} grams");
            
            return sb.ToString().Trim();
        }

        public void Add(IEquipment model)
        {
            models.Add(model);
        }

        public bool Remove(IEquipment model)
        {
            bool result = models.Remove(model);
            return result;
        }

        public IEquipment FindByType(string type)
        {
            IEquipment equipment = models.FirstOrDefault(x => x.GetType().Name == type);
            return equipment;
        }
    }
}
