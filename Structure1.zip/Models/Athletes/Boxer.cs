﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Athletes
{
    public class Boxer : Athlete
    {
        public Boxer(string name, string motivation, int numberOfMedals) : base(name, motivation, numberOfMedals, 60) { }

        public override void Exercise()
        {
            base.Stamina += 15;

            if (base.Stamina > 100)
            {
                base.Stamina = 100;
                throw new ArgumentException(Utilities.Messages.ExceptionMessages.InvalidStamina);
            }
        }
    }
}
