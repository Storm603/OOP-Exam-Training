﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Models.Athletes
{
    public class Weightlifter : Athlete
    {
        public Weightlifter(string name, string motivation, int numberOfMedals) : base(name, motivation, numberOfMedals, 50) { }

        public override void Exercise()
        {
            base.Stamina += 10;
        }
    }
}
