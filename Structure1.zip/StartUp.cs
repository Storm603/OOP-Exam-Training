﻿using System;
using Gym.Models.Equipment;
using Gym.Models.Equipment.Contracts;
using Gym.Models.Gyms;
using Gym.Models.Gyms.Contracts;
using Gym.Repositories.Contracts;

namespace Gym
{
    using Gym.Core;
    using Gym.Core.Contracts;
    public class StartUp
    {
        public static void Main()
        {
            // Don't forget to comment out the commented code lines in the Engine class!
            IGym gym = new BoxingGym("boxing");

            IEquipment gloves = new BoxingGloves();
            IEquipment kettle = new Kettlebell();

            IRepository<IEquipment> repository = new BoxingGym("sda");

            repository.Add(gloves);
            gym.AddEquipment(gloves);
            repository.Add(kettle);
            gym.AddEquipment(kettle);

            IEquipment equipment = repository.FindByType("BoxingGloves");

            Console.WriteLine(gym.GymInfo());

            foreach (IEquipment model in repository.Models)
            {
                Console.WriteLine(model.Price.GetType().FullName);
                Console.WriteLine(model.Weight.GetType().Name);
            }

            //IEngine engine = new Engine();
            //engine.Run();
        }
    }
}
