﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using Gym.Models.Equipment;
using Gym.Models.Equipment.Contracts;
using Gym.Models.Gyms.Contracts;
using Gym.Repositories;
using Gym.Repositories.Contracts;

namespace Gym.Core
{
    using Gym.Core.Contracts;
    using Gym.IO;
    using Gym.IO.Contracts;
    using System;

    public class Engine : IEngine
    {
        private IWriter writer;
        private IReader reader;
        private IController controller;
        public Engine()
        {
            this.writer = new Writer();
            this.reader = new Reader();
            this.controller = new Controller();
        }

        public void Run()
        {
            while (true)
            {
                string[] input = reader.ReadLine().Split();
                if (input[0] == "Exit")
                {
                    Environment.Exit(0);
                }
                try
                {
                    string result = string.Empty;

                    if (input[0] == "AddGym")
                    {
                        string gymType = input[1];
                        string gymName = input[2];

                        if (gymType != "BoxingGym" && gymType != "WeightliftingGym")
                        {
                            throw new InvalidOperationException(Utilities.Messages.ExceptionMessages.InvalidGymType);
                        }

                        result = controller.AddGym(gymType, gymName);
                    }
                    else if (input[0] == "AddEquipment")
                    {
                        string equipmentType = input[1];

                        if (equipmentType != "BoxingGloves" && equipmentType != "Kettlebell")
                        {
                            throw new InvalidOperationException(Utilities.Messages.ExceptionMessages.InvalidEquipmentType);
                        }

                        result = controller.AddEquipment(equipmentType);
                    }
                    else if (input[0] == "InsertEquipment")
                    {
                        string gymName = input[1];
                        string equipmentType = input[2];

                        result = controller.InsertEquipment(gymName, equipmentType);

                        if (result == "false")
                        {
                            throw new InvalidOperationException($"{Utilities.Messages.ExceptionMessages.InexistentEquipment}{equipmentType}.");
                        }


                    }
                    else if (input[0] == "AddAthlete")
                    {
                        string gymName = input[1];
                        string athleteType = input[2];
                        string athleteName = input[3];
                        string motivation = input[4];
                        int numberOfMedals = int.Parse(input[5]);

                        if (athleteType != "Boxer" && athleteType != "Weightlifter")
                        {
                            throw new InvalidOperationException(Utilities.Messages.ExceptionMessages.InvalidAthleteType);
                        }

                        result = controller.AddAthlete(gymName, athleteType, athleteName, motivation, numberOfMedals);
                    }
                    else if (input[0] == "TrainAthletes")
                    {
                        string gymName = input[1];

                        result = controller.TrainAthletes(gymName);
                    }
                    else if (input[0] == "EquipmentWeight")
                    {
                        string gymName = input[1];

                        result = controller.EquipmentWeight(gymName);
                    }
                    else if (input[0] == "Report")
                    {
                        result = controller.Report();
                    }

                    writer.WriteLine(result);
                }
                catch (Exception ex)
                {
                    writer.WriteLine(ex.Message);
                }
            }
        }
    }
}
