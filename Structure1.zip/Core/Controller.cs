﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Gym.Core.Contracts;
using Gym.Models.Athletes;
using Gym.Models.Athletes.Contracts;
using Gym.Models.Equipment;
using Gym.Models.Equipment.Contracts;
using Gym.Models.Gyms;
using Gym.Models.Gyms.Contracts;
using Gym.Repositories;
using Gym.Repositories.Contracts;

namespace Gym.Core
{
    public class Controller : IController
    {
        public Controller()
        {
            equipment = new EquipmentRepository();
            gyms = new List<IGym>();
        }
        private EquipmentRepository equipment;
       
        private List<IGym> gyms;
        public string AddGym(string gymType, string gymName)
        {
            IGym gym = null;
            if (gymType == "BoxingGym")
            {
                gym = new BoxingGym(gymName);
            }
            else if (gymType == "WeightliftingGym")
            {
                gym = new WeightliftingGym(gymName);
            }

            gyms.Add(gym);
            return $"Successfully added {gymType}.";
        }

        public string AddEquipment(string equipmentType)
        {
            IEquipment gear = null;
            if (equipmentType == "BoxingGloves")
            {
                gear = new BoxingGloves();
            }
            else if (equipmentType == "Kettlebell")
            {
                gear = new Kettlebell();
            }

            equipment.Add(gear);
            return $"Successfully added {equipmentType}.";
        }

        public string InsertEquipment(string gymName, string equipmentType)
        {
            IEquipment gear = equipment.Models.FirstOrDefault(x => x.GetType().Name == equipmentType);
            IGym gym = gyms.FirstOrDefault(x => x.Name == gymName);

            bool resultt = equipment.Models.Any(x => x.GetType().Name == equipmentType);

            if (!resultt)
            {
                return "false";
            }
            gym.AddEquipment(gear);
            equipment.Remove(gear);

            return $"Successfully added {equipmentType} to {gymName}.";
        }

        public string AddAthlete(string gymName, string athleteType, string athleteName, string motivation, int numberOfMedals)
        {
            IGym gymm = gyms.FirstOrDefault(x => x.Name == gymName);

            string gym = gymm.GetType().Name;

            if (athleteType == "Boxer" && gym == "WeightliftingGym" || athleteType == "Weightlifter" && gym == "BoxingGym")
            {
                return "The gym is not appropriate.";
            }
            
            IAthlete athlete = null;

            if (athleteType == "Boxer")
            {
                athlete = new Boxer(athleteName, motivation, numberOfMedals);
            }
            else if (athleteType == "Weightlifter")
            {
                athlete = new Weightlifter(athleteName, motivation, numberOfMedals);
            }

            gymm.AddAthlete(athlete);

            return $"Successfully added {athleteType} to {gymName}.";
        }

        public string TrainAthletes(string gymName)
        {
            IGym gym = gyms.FirstOrDefault(x => x.Name == gymName);
            foreach (IAthlete athlete in gym.Athletes)
            {
                athlete.Exercise();
            }

            return $"Exercise athletes: {gym.Athletes.Count}.";
        }

        public string EquipmentWeight(string gymName)
        {
            double equipmentWeight = gyms.FirstOrDefault(x => x.Name == gymName).EquipmentWeight;

            return $"The total weight of the equipment in the gym {gymName} is {equipmentWeight:f2} grams.";
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            gyms.ForEach(x => sb.AppendLine(x.GymInfo()));

            return sb.ToString().Trim();
        }
    }
}
