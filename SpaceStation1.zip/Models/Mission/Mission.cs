﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Mission.Contracts;
using SpaceStation.Models.Planets.Contracts;

namespace SpaceStation.Models.Mission
{
    public class Mission : IMission
    {
        public void Explore(IPlanet planet, ICollection<IAstronaut> astronauts)
        {
            foreach (IAstronaut astronaut in astronauts)
            {
                List<string> items = planet.Items.ToList();

                while (astronaut.CanBreath)
                {
                    string item = items[items.Count - 1];

                    planet.Items.Remove(item);

                    astronaut.Bag.Items.Add(item);
                    
                    astronaut.Breath();
                }
            }
        }
    }
}
