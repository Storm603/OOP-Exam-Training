﻿using System;
using System.Collections.Generic;
using System.Text;
using SpaceStation.Models.Planets.Contracts;

namespace SpaceStation.Models.Planets
{
    public class Planet : IPlanet
    {
        public Planet(string name)
        {
            items = new List<string>();
            Name = name;
        }

        private string name;
        private List<string> items;
        public ICollection<string> Items => items;
        public string Name
        {
            get { return name; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(Utilities.Messages.ExceptionMessages.InvalidPlanetName);
                }

                name = value;
            }
        }

        
    }
}
