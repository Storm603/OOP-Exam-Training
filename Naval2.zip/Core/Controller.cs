﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NavalVessels.Core.Contracts;
using NavalVessels.Models;
using NavalVessels.Models.Contracts;
using NavalVessels.Repositories;

namespace NavalVessels.Core
{
    public class Controller : IController
    {
        public Controller()
        {
            vessels = new VesselRepository();
            captains = new List<ICaptain>();
        }

        private VesselRepository vessels;
        private List<ICaptain> captains;

        public string HireCaptain(string fullName)
        {
            ICaptain captain = captains.FirstOrDefault(x => x.FullName == fullName);

            if (captain != null)
            {
                return string.Format(Utilities.Messages.OutputMessages.CaptainIsAlreadyHired, fullName);
            }

            captain = new Captain(fullName);

            captains.Add(captain);

            return string.Format(Utilities.Messages.OutputMessages.SuccessfullyAddedCaptain, fullName);
        }

        public string ProduceVessel(string name, string vesselType, double mainWeaponCaliber, double speed)
        {
            IVessel vessel = vessels.Models.FirstOrDefault(x => x.Name == name);

            if (vessel != null)
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselIsAlreadyManufactured, vesselType, name);
            }

            if (vesselType == "Battleship")
            {
                vessel = new Battleship(name, mainWeaponCaliber, speed);
            }
            else if (vesselType == "Submarine")
            {
                vessel = new Submarine(name, mainWeaponCaliber, speed);
            }
            else
            {
                return Utilities.Messages.OutputMessages.InvalidVesselType;
            }

            vessels.Add(vessel);
            return string.Format(Utilities.Messages.OutputMessages.SuccessfullyCreateVessel, vesselType, name, mainWeaponCaliber, speed);
        }

        public string AssignCaptain(string selectedCaptainName, string selectedVesselName)
        {
            ICaptain captain = captains.FirstOrDefault(x => x.FullName == selectedCaptainName);
            IVessel vessel = vessels.FindByName(selectedVesselName);

            if (captain == null)
            {
                return string.Format(Utilities.Messages.OutputMessages.CaptainNotFound, selectedCaptainName);
            }

            if (vessel == null)
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselNotFound, selectedVesselName);
            }

            if (vessel.Captain != null)
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselOccupied, selectedVesselName);
            }

            vessel.Captain = captain;
            captain.AddVessel(vessel);

            return string.Format(Utilities.Messages.OutputMessages.SuccessfullyAssignCaptain, selectedCaptainName, selectedVesselName);
        }

        public string CaptainReport(string captainFullName)                                 // POSSIBLE ASSIGNED CAPTAIN PROBLEM
        {
            ICaptain captain = captains.FirstOrDefault(x => x.FullName == captainFullName);

            return captain.Report();
        }

        public string VesselReport(string vesselName)
        {
            IVessel vessel = vessels.FindByName(vesselName);

            return vessel.ToString();
        }

        public string ToggleSpecialMode(string vesselName)
        {
            IVessel vessel = vessels.FindByName(vesselName);

            if (vessel is Battleship)
            {
                IBattleship bs = vessel as Battleship;
                bs.ToggleSonarMode();
                return string.Format(Utilities.Messages.OutputMessages.ToggleBattleshipSonarMode, vesselName);
            }
            if (vessel is Submarine)
            {
                ISubmarine sm = vessel as Submarine;
                sm.ToggleSubmergeMode();
                return string.Format(Utilities.Messages.OutputMessages.ToggleSubmarineSubmergeMode, vesselName);
            }

            return string.Format(Utilities.Messages.OutputMessages.VesselNotFound, vesselName);
        }

        public string AttackVessels(string attackingVesselName, string defendingVesselName)
        {
            IVessel attacker = vessels.FindByName(attackingVesselName);
            IVessel defender = vessels.FindByName(defendingVesselName);

            if (attacker == null)
            {
                return String.Format(Utilities.Messages.OutputMessages.VesselNotFound, attackingVesselName);
            }
            if (defender == null)
            {
                return String.Format(Utilities.Messages.OutputMessages.VesselNotFound, defendingVesselName);
            }

            if (attacker.ArmorThickness == 0)
            {
                return string.Format(Utilities.Messages.OutputMessages.AttackVesselArmorThicknessZero,
                    attackingVesselName);
            }

            if (defender.ArmorThickness == 0)
            {
                return string.Format(Utilities.Messages.OutputMessages.AttackVesselArmorThicknessZero,
                    defender);
            }

            attacker.Attack(defender);
            attacker.Captain.IncreaseCombatExperience();
            defender.Captain.IncreaseCombatExperience();

            return string.Format(Utilities.Messages.OutputMessages.SuccessfullyAttackVessel, defendingVesselName,
                attackingVesselName, defender.ArmorThickness);
        }

        public string ServiceVessel(string vesselName)
        {
            IVessel vessel = vessels.FindByName(vesselName);

            if (vessel == null)
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselNotFound, vesselName);
            }

            vessel.RepairVessel();
            return string.Format(Utilities.Messages.OutputMessages.SuccessfullyRepairVessel, vesselName);
        }
    }
}
