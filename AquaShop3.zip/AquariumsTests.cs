﻿using NUnit.Framework;

namespace Aquariums.Tests
{
    using System;

    public class AquariumsTests
    {
        [Test]
        public void Name_Test()
        {
            Aquarium aqiaruim = new Aquarium("name", 10);

            Assert.That("name" == aqiaruim.Name);

            Assert.Throws<ArgumentNullException>(() =>new Aquarium("", 10));
            Assert.Throws<ArgumentNullException>(() =>new Aquarium( null, 10));
        }

        [Test]
        public void Capacity_Test()
        {
            Aquarium aquarium = new Aquarium("name", 10);

            Assert.That(aquarium.Capacity == 10);

            Assert.Throws<ArgumentException>(() => new Aquarium("dasfsaff", -1));
        }
        [Test]
        public void AddTestPlusCountTest()
        {
            Aquarium aquarium = new Aquarium("name", 3);

            Fish fish0 = new Fish("fish1");
            Fish fish1 = new Fish("fish2");
            Fish fish2 = new Fish("fish3");
            Fish fish3 = new Fish("fish4");

            aquarium.Add(fish0);
            aquarium.Add(fish1);
            aquarium.Add(fish2);

            Assert.That(aquarium.Count == 3);

            Assert.Throws<InvalidOperationException>(() => aquarium.Add(fish3));
        }
        [Test]
        public void RemoveTest()
        {
            Aquarium aquarium = new Aquarium("name", 3);

            Fish fish0 = new Fish("fish1");

            Assert.Throws<InvalidOperationException>(() => aquarium.RemoveFish("dsafsad"));

            Fish fish1 = new Fish("fish2");
            Fish fish2 = new Fish("fish3");

            aquarium.Add(fish1);
            aquarium.Add(fish2);

            Assert.That(aquarium.Count == 2);

            aquarium.RemoveFish("fish2");

            Assert.That(aquarium.Count == 1);
        }
        [Test]
        public void SellFish()
        {
            Aquarium aquarium = new Aquarium("name", 3);

            Fish fish0 = new Fish("fish1");

            aquarium.Add(fish0);

            Assert.Throws<InvalidOperationException>(() => aquarium.SellFish("safsa"));

            Fish fish = aquarium.SellFish("fish1");

            Assert.That(!fish0.Available);

            Assert.That(fish == fish0);
        }
        [Test]
        public void Reported()
        {
            Aquarium aquarium = new Aquarium("name", 3);

            Fish fish0 = new Fish("fish1");

            aquarium.Add(fish0);

            string report = aquarium.Report();

            Assert.That("Fish available at name: fish1" == report);
        }
    }
}
