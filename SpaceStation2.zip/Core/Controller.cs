﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SpaceStation.Models.Astronauts;
using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Mission;
using SpaceStation.Models.Mission.Contracts;
using SpaceStation.Models.Planets;
using SpaceStation.Models.Planets.Contracts;

namespace SpaceStation.Core.Contracts
{
    public class Controller : IController
    {
        public Controller()
        {
            planets = new List<IPlanet>();
            astonauts = new List<IAstronaut>();
        }

        private int exploredPlanets;
        private List<IPlanet> planets;
        private List<IAstronaut> astonauts;
        public string AddAstronaut(string type, string astronautName)
        {
            IAstronaut astronaut;
            if (type == "Biologist")
            {
                astronaut = new Biologist(astronautName);
            }
            else if (type == "Geodesist")
            {
                astronaut = new Geodesist(astronautName);
            }
            else if (type == "Meteorologist")
            {
                astronaut = new Meteorologist(astronautName);
            }
            else
            {
                throw new InvalidOperationException(Utilities.Messages.ExceptionMessages.InvalidAstronautType);
            }

            astonauts.Add(astronaut);
            return string.Format(Utilities.Messages.OutputMessages.AstronautAdded, type, astronautName);
        }

        public string AddPlanet(string planetName, params string[] items)
        {
            IPlanet planet = new Planet(planetName);

            foreach (string item in items)
            {
                planet.Items.Add(item);
            }
            planets.Add(planet);
            return string.Format(Utilities.Messages.OutputMessages.PlanetAdded, planetName);
        }

        public string RetireAstronaut(string astronautName)
        {
            IAstronaut astronaut = astonauts.FirstOrDefault(x => x.Name == astronautName);

            if (astronaut == null)
            {
                throw new InvalidOperationException(
                    string.Format(Utilities.Messages.ExceptionMessages.InvalidRetiredAstronaut, astronautName));
            }

            astonauts.Remove(astronaut);
            return string.Format(Utilities.Messages.OutputMessages.AstronautRetired, astronautName);
        }

        public string ExplorePlanet(string planetName)
        {
            List<IAstronaut> suitableAstros = astonauts.Where(x => x.Oxygen > 60).ToList();

            if (suitableAstros.Count == 0)
            {
                throw new InvalidOperationException(Utilities.Messages.ExceptionMessages.InvalidAstronautCount);
            }

            IPlanet planet = planets.Find(x => x.Name == planetName);

            IMission mission = new Mission();
            mission.Explore(planet, suitableAstros);

            exploredPlanets++;

            return string.Format(Utilities.Messages.OutputMessages.PlanetExplored, planetName,
                suitableAstros.Count(x => x.Oxygen == 0));
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();
            string str = String.Empty;
            
            str += $"{exploredPlanets} planets were explored!\nAstronauts info:";
            foreach (IAstronaut astronaut in astonauts)
            {
                str += $"\nName: {astronaut.Name}\nOxygen: {astronaut.Oxygen}\nBag items: {(astronaut.Bag.Items.Count == 0 ? "none" : string.Join(", ", astronaut.Bag.Items.ToList()))}";
            }

            return str;
        }
    }
}
