﻿using System;
using System.Collections.Generic;
using System.Text;
using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Bags;
using SpaceStation.Models.Bags.Contracts;

namespace SpaceStation.Models.Astronauts
{
    public abstract class Astronaut : IAstronaut
    {
        public Astronaut(string name, double oxygen)
        {
            Name = name;
            Oxygen = oxygen;
            Bag = new Backpack();
            CanBreath = true;
        }

        private string name;
        protected double oxygen;
        public string Name
        {
            get { return name;}
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(Utilities.Messages.ExceptionMessages.InvalidAstronautName);
                }

                name = value;
            }
        }
        public double Oxygen
        {
            get
            {
                return oxygen;
            }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(Utilities.Messages.ExceptionMessages.InvalidOxygen);
                }

                oxygen = value;
            }
        }

        public bool CanBreath { get; set; }
        public IBag Bag { get; private set; }
        public virtual void Breath()
        {
            if (oxygen - 10 >= 0)
            {
                oxygen -= 10;
                CanBreath = true;
            }
            else
            {
                CanBreath = false;
            }
        }
    }
}
