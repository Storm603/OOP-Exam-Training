﻿using System;
using System.Linq;

namespace Presents.Tests
{
    using NUnit.Framework;
    using System.Collections.Generic;

    [TestFixture]
    public class PresentsTests
    {
        [Test]
        public void CreateTest()
        {
            Bag bag = new Bag();
            

            Assert.Throws<ArgumentNullException>(() => bag.Create(null));


            string result = bag.Create(new Present("name", 10));
            Assert.That(result == "Successfully added present name.");

            Present presento = new Present("name", 10);
            bag.Create(presento);
            Assert.Throws<InvalidOperationException>(() => bag.Create(presento));

        }

        [Test]
        public void RemoveTest()
        {
            Bag bag = new Bag();

            Present present = new Present("name", 10);

            bag.Create(present);

            Assert.That(bag.Remove(present));

            Assert.That(!bag.Remove(new Present("dasfa", 10)));
        }

        [Test]
        public void GetPresentLeastMagicTest()
        {
            Bag bag = new Bag();

            Present present = new Present("name", 10);
            Present present1 = new Present("name1", 5);



            bag.Create(present);
            bag.Create(present1);

            Present result = bag.GetPresentWithLeastMagic();

            Assert.That(result == present1);
        }

        //[Test]
        //public void GetNoPresentLeastMagicTest()
        //{
        //    Bag bag = new Bag();

        //    Present result1 = bag.GetPresentWithLeastMagic();

        //    Assert.Throws<Exception>(() => bag.GetPresentWithLeastMagic());
        //}
        [Test]
        public void GetPresentTest()
        {
            Bag bag = new Bag();

            Present present = new Present("name", 10);
            Present present1 = new Present("name1", 5);

            Present result1 = bag.GetPresent("sdghsd");

            Assert.That(result1 == null);

            bag.Create(present);
            bag.Create(present1);

            Present result = bag.GetPresent("name1");

            Assert.That(result == present1);
        }

        [Test]
        public void GettingPresentsTest()
        {
            Bag bag = new Bag();

            Present present = new Present("name", 10);

            List<Present> presents1 = bag.GetPresents().ToList();

            Assert.That(presents1.Count == 0);

            bag.Create(present);

            List<Present> presents = bag.GetPresents().ToList();

            Assert.That(presents.Contains(present));
        }
    }
}
