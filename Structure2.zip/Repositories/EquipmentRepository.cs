﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gym.Models.Equipment.Contracts;
using Gym.Repositories.Contracts;

namespace Gym.Repositories
{
    public class EquipmentRepository : IRepository<IEquipment>
    {
        private List<IEquipment> models = new List<IEquipment>();
        public IReadOnlyCollection<IEquipment> Models => models.AsReadOnly();
        public void Add(IEquipment model)
        {
            models.Add(model);
        }

        public bool Remove(IEquipment model)
        {
            bool result = models.Remove(model);
            return result;
        }

        public IEquipment FindByType(string type)
        {
            IEquipment equipment = models.FirstOrDefault(x => x.GetType().Name == type);
            return equipment;
        }
    }
}
