﻿using System;
using System.Collections.Generic;
using System.Text;
using NavalVessels.Models.Contracts;

namespace NavalVessels.Models
{
    public abstract class Vessel : IVessel
    {
        public Vessel(string name, double mainWeaponCaliber, double speed, double armorThickness)
        {
            Name = name;
            MainWeaponCaliber = mainWeaponCaliber;
            Speed = speed;
            ArmorThickness = armorThickness;
            initialArmorThickness = armorThickness;
            targets = new List<string>();
        }

        private string name;
        private ICaptain captain;
        private double mainWeaponCaliber;
        private double armorThickness;
        protected double initialArmorThickness { get; private set; }    //  POSSIBLE JUDGE ERROR
        private double speed;
        private List<string> targets;
        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(Utilities.Messages.ExceptionMessages.InvalidVesselName);
                }

                name = value;
            }
        }

        public ICaptain Captain
        {
            get => captain;
            set
            {
                if (value == null)
                {
                    throw new NullReferenceException(Utilities.Messages.ExceptionMessages.InvalidCaptainToVessel);
                }

                captain = value;
            }
        }

        public double ArmorThickness
        {
            get => armorThickness;
            set
            {
                if (value < 0)
                {
                    armorThickness = 0;
                }
                else
                {
                    armorThickness = value;
                }
            }
        } // possible mistake in judge

        public double MainWeaponCaliber
        {
            get => mainWeaponCaliber;
            protected set => mainWeaponCaliber = value;
        }

        public double Speed
        {
            get => speed;
            protected set => speed = value;
        }
        public ICollection<string> Targets => targets;
        

        public void Attack(IVessel target)
        {
            if (target == null)
            {
                throw new NullReferenceException(Utilities.Messages.ExceptionMessages.InvalidTarget);
            }
            targets.Add(target.Name);

            target.ArmorThickness -= this.mainWeaponCaliber;
        }

        public virtual void RepairVessel()                                        // POSSIBLE JUDGE ERROR
        {
            this.ArmorThickness = initialArmorThickness;
        }

        public virtual string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"- {this.name}");
            sb.AppendLine($" *Type: {this.GetType().Name}");
            sb.AppendLine($" *Armor thickness: {this.armorThickness}");
            sb.AppendLine($" *Main weapon caliber: {this.mainWeaponCaliber}");
            sb.AppendLine($" *Speed: {this.speed}");
            sb.AppendLine($" *Targets: {(targets.Count == 0 ? "None" : string.Join(", ", targets))}");

            return sb.ToString().Trim();
        }
    }
}
