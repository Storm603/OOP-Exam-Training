﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NavalVessels.Models.Contracts
{
    public class Battleship : Vessel, IBattleship
    {
        public Battleship(string name, double mainWeaponCaliber, double speed) : base(name, mainWeaponCaliber, speed, 300) { }

        private bool sonarMode;
        public bool SonarMode
        {
            get => sonarMode;
            private set => sonarMode = value;
        }

        public void ToggleSonarMode()
        {
            if (sonarMode)
            {
                SonarMode = false;
                this.MainWeaponCaliber -= 40;
                this.Speed += 5;
            }
            else
            {
                SonarMode = true;
                this.MainWeaponCaliber += 40;
                this.Speed -= 5;
            }
        }

        public override void RepairVessel()                           //     POSSIBLE JUDGE ERROR    
        {
            if (this.ArmorThickness < this.initialArmorThickness)
            {
                base.RepairVessel();
            }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.ToString());
            sb.AppendLine($" *Sonar mode: {(sonarMode ? "ON" : "OFF")}");

            return sb.ToString().Trim();
        }
    }
}
