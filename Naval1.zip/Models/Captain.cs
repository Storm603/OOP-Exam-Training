﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using NavalVessels.Models.Contracts;

namespace NavalVessels.Models
{
    public class Captain : ICaptain
    {
        public Captain(string name)
        {
            FullName = name;
            vessels = new List<IVessel>();
        }
        private string fullName;
        private int combatExperience;
        private List<IVessel> vessels;
        public string FullName
        {
            get => fullName;
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(Utilities.Messages.ExceptionMessages.InvalidCaptainName);
                }

                fullName = value;
            }
        }
        public int CombatExperience
        {
            get => combatExperience;
            private set => combatExperience = value;
        }

        public ICollection<IVessel> Vessels => vessels;
        public void AddVessel(IVessel vessel)
        {
            if (vessel == null)
            {
                throw new NullReferenceException(Utilities.Messages.ExceptionMessages.InvalidVesselForCaptain);
            }

            vessels.Add(vessel);
        }

        public void IncreaseCombatExperience()   // USE WHEN ATTACKING AND DEFENDING
        {
            this.CombatExperience += 10;
        }

        public string Report()
        {
            if (vessels.Count > 0)
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendLine($"{fullName} has {combatExperience} combat experience and commands {vessels.Count} vessels.");
                foreach (IVessel vessel in vessels)
                {
                    sb.AppendLine(vessel.ToString());
                }

                return sb.ToString().Trim();
            }

            return null;
        }
    }
}
