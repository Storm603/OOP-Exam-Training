﻿using System;

using WarCroft.Constants;
using WarCroft.Entities.Inventory;
using WarCroft.Entities.Items;

namespace WarCroft.Entities.Characters.Contracts
{
    public abstract class Character
    {
        public Character(string name, double health, double armor, double abilityPoints, Bag bag)
        {
            Name = name;
            Health = health;
            BaseHealth = health;
            Armor = armor;
            BaseArmor = armor;
            AbilityPoints = abilityPoints;
            Bag = bag;
        }

        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(Constants.ExceptionMessages.CharacterNameInvalid);
                }
                name = value;
            }

        }

        public double BaseHealth { get; set; }
        public double Health { get; set; }
        public double BaseArmor { get; set; }
        public double Armor { get; set; }
        public double AbilityPoints { get; set; }
        public Bag Bag { get; set; }
        public bool IsAlive { get; set; } = true;

        public void TakeDamage(double hitPoints)
        {
            if (this.IsAlive)
            {
                if (Armor > 0)
                {
                    if (this.Armor - hitPoints <= 0)
                    {
                        hitPoints -= Armor;
                        Armor = 0;
                    }
                    else
                    {
                        Armor -= hitPoints;
                        return;
                    }
                }

                if (Health - hitPoints <= 0)
                {
                    IsAlive = false;
                    Health = 0;
                    return;
                }

                Health -= hitPoints;

            }
        }

        public void UseItem(Item item)
        {
            if (IsAlive)
            {
                item.AffectCharacter(this);
            }
        }
        protected void EnsureAlive()
        {
            if (!this.IsAlive)
            {
                throw new InvalidOperationException(ExceptionMessages.AffectedCharacterDead);
            }
        }
    }
}