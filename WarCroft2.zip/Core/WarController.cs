﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using WarCroft.Entities.Characters;
using WarCroft.Entities.Characters.Contracts;
using WarCroft.Entities.Items;

namespace WarCroft.Core
{
    public class WarController
    {
        public WarController()
        {
            party = new List<Character>();
            itemPool = new List<Item>();
        }

        private List<Character> party;
        public IReadOnlyCollection<Character> Party => party.AsReadOnly();

        private List<Item> itemPool;
        public IReadOnlyCollection<Item> ItemPool => itemPool.AsReadOnly();

        public string JoinParty(string[] args)                                  // possible 2 parties for different character types
        {
            string characterType = args[0];
            string name = args[1];

            if (characterType != "Warrior" && characterType != "Priest")
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.InvalidCharacterType, characterType));
            }

            Character character = null;
            if (characterType == "Warrior")
            {
                character = new Warrior(name);
            }
            else if (characterType == "Priest")
            {
                character = new Priest(name);
            }

            party.Add(character);

            return String.Format(Constants.SuccessMessages.JoinParty, name);
        }

        public string AddItemToPool(string[] args)
        {
            string itemName = args[0];

            if (itemName != "FirePotion" && itemName != "HealthPotion")
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.InvalidItem, itemName));
            }

            Item item = null;

            if (itemName == "FirePotion")
            {
                item = new FirePotion();
            }
            else if (itemName == "HealthPotion")
            {
                item = new HealthPotion();
            }

            itemPool.Add(item);
            return string.Format(Constants.SuccessMessages.AddItemToPool, itemName);
        }

        public string PickUpItem(string[] args)
        {
            string characterName = args[0];

            Character character = party.FirstOrDefault(x => x.Name == characterName);

            if (character == null)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.CharacterNotInParty, characterName));
            }

            if (itemPool.Count == 0)
            {
                throw new ArgumentException(Constants.ExceptionMessages.ItemPoolEmpty);
            }

            Item item = itemPool[itemPool.Count - 1];
            itemPool.RemoveAt(itemPool.Count - 1);
            character.Bag.AddItem(item);

            return string.Format(Constants.SuccessMessages.PickUpItem, characterName, item.GetType().Name);
        }

        public string UseItem(string[] args)
        {
            string characterName = args[0];
            string itemName = args[1];

            Character character = party.FirstOrDefault(x => x.Name == characterName);

            if (character == null)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.CharacterNotInParty, characterName));
            }

            Item item = character.Bag.GetItem(itemName);
            character.UseItem(item);
            return string.Format(Constants.SuccessMessages.UsedItem, characterName, itemName);
        }

        public string GetStats()
        {
            StringBuilder sb = new StringBuilder();

            foreach (Character character in party.OrderByDescending(x => x.IsAlive).ThenByDescending(x => x.Health))
            {
                sb.AppendLine(string.Format(Constants.SuccessMessages.CharacterStats, character.Name, character.Health, character.BaseHealth, character.Armor, character.BaseArmor, (character.IsAlive ? "Alive" : "Dead")));
            }

            return sb.ToString().Trim();
        }

        public string Attack(string[] args)
        {
            string attackerName = args[0];
            string recieverName = args[1];

            Character attacker = party.FirstOrDefault(x => x.Name == attackerName);
            Character reciever = party.FirstOrDefault(x => x.Name == recieverName);

            if (attacker == null)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.CharacterNotInParty, attackerName));
            }

            if (reciever == null)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.CharacterNotInParty, recieverName));
            }

            if (!attacker.IsAlive)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.AttackFail, attackerName));
            }

            if (!reciever.IsAlive)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.AffectedCharacterDead, attackerName));
            }
            IAttacker war = attacker as IAttacker;
            war.Attack(reciever);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(String.Format(Constants.SuccessMessages.AttackCharacter, attackerName, recieverName, attacker.AbilityPoints, recieverName, reciever.Health,reciever.BaseHealth,reciever.Armor, reciever.BaseArmor));

            if (!reciever.IsAlive)
            {
                sb.AppendLine(string.Format(Constants.SuccessMessages.AttackKillsCharacter, recieverName));
            }

            return sb.ToString().Trim();
        }

        public string Heal(string[] args)
        {
            string healerName = args[0];
            string healingRecieverName = args[1];

            Character healer = party.FirstOrDefault(x => x.Name == healerName);
            Character reciever = party.FirstOrDefault(x => x.Name == healingRecieverName);

            if (healer == null)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.CharacterNotInParty, healerName));
            }

            if (reciever == null)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.CharacterNotInParty, healingRecieverName));
            }

            if (!healer.IsAlive)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.HealerCannotHeal, healerName));
            }

            if (!reciever.IsAlive)
            {
                throw new ArgumentException(string.Format(Constants.ExceptionMessages.AffectedCharacterDead, healerName));
            }

            IHealer heal = healer as IHealer;
            heal.Heal(reciever);
            return string.Format(Constants.SuccessMessages.HealCharacter, healerName, healingRecieverName, healer.AbilityPoints, healingRecieverName, reciever.Health);
        }
    }
}
