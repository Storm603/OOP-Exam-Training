﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NavalVessels.Models;
using NavalVessels.Models.Contracts;

namespace NavalVessels.Core.Contracts
{
    public class Controller : IController
    {
        public Controller()
        {
            vessels = new List<IVessel>();
            captains = new List<ICaptain>();
        }

        private List<IVessel> vessels;
        private List<ICaptain> captains;

        public string HireCaptain(string fullName)
        {
            if (captains.Any(x => x.FullName == fullName))
            {
                return string.Format(Utilities.Messages.OutputMessages.CaptainIsAlreadyHired, fullName);
            }

            ICaptain captain = new Captain(fullName);
            captains.Add(captain);
            return string.Format(Utilities.Messages.OutputMessages.SuccessfullyAddedCaptain, fullName);
        }

        public string ProduceVessel(string name, string vesselType, double mainWeaponCaliber, double speed)
        {
            if (vessels.Any(x => x.Name == name))
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselIsAlreadyManufactured, vesselType, name);
            }

            if (vesselType != "Battleship" && vesselType != "Submarine")
            {
                return Utilities.Messages.OutputMessages.InvalidVesselType;
            }

            IVessel vessel = null;
            if (vesselType == "Battleship")
            {
                vessel = new Battleship(name, mainWeaponCaliber, speed);
            }
            else if (vesselType == "Submarine")
            {
                vessel = new Submarine(name, mainWeaponCaliber, speed);
            }

            vessels.Add(vessel);
            return string.Format(Utilities.Messages.OutputMessages.SuccessfullyCreateVessel, vesselType, name, mainWeaponCaliber, speed);
        }

        public string AssignCaptain(string selectedCaptainName, string selectedVesselName)
        {
            if (!captains.Any(x => x.FullName == selectedCaptainName))
            {
                return string.Format(Utilities.Messages.OutputMessages.CaptainNotFound, selectedCaptainName);
            }

            if (Equals(!vessels.Any(x => x.Name == selectedVesselName)))
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselNotFound, selectedVesselName);
            }

            IVessel vessel = vessels.First(x => x.Name == selectedVesselName);

            if (vessel.Captain != null)
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselOccupied, selectedCaptainName);
            }

            ICaptain captain = captains.First(x => x.FullName == selectedCaptainName);

            vessel.Captain = captain;
            captain.AddVessel(vessel);
            return string.Format(Utilities.Messages.OutputMessages.SuccessfullyAssignCaptain, selectedCaptainName,
                selectedVesselName);
        }

        public string CaptainReport(string captainFullName)
        {
            ICaptain captain = captains.FirstOrDefault(x => x.FullName == captainFullName);
            return captain.Report();
        }

        public string VesselReport(string vesselName)
        {
            IVessel vessel = vessels.FirstOrDefault(x => x.Name == vesselName);
            return vessel.ToString();
        }

        public string ToggleSpecialMode(string vesselName)
        {
            IVessel vessel = vessels.FirstOrDefault(x => x.Name == vesselName);

            if (vessel != null)
            {
                if (vessel.GetType().Name == "Battleship")
                {
                    IBattleship basttleship = vessel as Battleship;
                    basttleship.ToggleSonarMode();
                    return String.Format(Utilities.Messages.OutputMessages.ToggleBattleshipSonarMode, vesselName);
                }

                if (vessel.GetType().Name == "Submarine")
                {
                    ISubmarine submarine = vessel as Submarine;
                    submarine.ToggleSubmergeMode();
                    return String.Format(Utilities.Messages.OutputMessages.ToggleSubmarineSubmergeMode, vesselName);
                }
            }

            return string.Format(Utilities.Messages.OutputMessages.VesselNotFound, vesselName);
        }

        public string AttackVessels(string attackingVesselName, string defendingVesselName)
        {
            IVessel attacking = vessels.FirstOrDefault(x => x.Name == attackingVesselName);
            IVessel defender = vessels.FirstOrDefault(x => x.Name == defendingVesselName);

            if (attacking == null)
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselNotFound, attackingVesselName);
            }

            if (defender == null)
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselNotFound, defendingVesselName);
            }

            if (attacking.ArmorThickness == 0)
            {
                return string.Format(Utilities.Messages.OutputMessages.AttackVesselArmorThicknessZero, attackingVesselName);
            }

            if (defender.ArmorThickness == 0)
            {
                return string.Format(Utilities.Messages.OutputMessages.AttackVesselArmorThicknessZero, defendingVesselName);
            }

            attacking.Attack(defender);
            return string.Format(Utilities.Messages.OutputMessages.SuccessfullyAttackVessel, defendingVesselName, attackingVesselName, defender.ArmorThickness);
        }

        public string ServiceVessel(string vesselName)
        {
            IVessel vessel = vessels.FirstOrDefault(x => x.Name == vesselName);

            if (vessel == null)
            {
                return string.Format(Utilities.Messages.OutputMessages.VesselNotFound, vesselName);
            }

            vessel.RepairVessel();
            return string.Join(Utilities.Messages.OutputMessages.SuccessfullyRepairVessel, vesselName);
        }
    }
}
