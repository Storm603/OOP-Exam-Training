﻿using System;
using System.Collections.Generic;
using System.Text;
using NavalVessels.Models.Contracts;

namespace NavalVessels.Models
{
    public class Captain : ICaptain
    {
        public Captain(string fullName)
        {
            FullName = fullName;
            CombatExperience = 0;
            vessels = new List<IVessel>();
        }

        private string name;
        public string FullName
        {
            get { return name;}
            set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new NullReferenceException(Utilities.Messages.ExceptionMessages.InvalidCaptainName);
                }

                name = value;
            }
        }

        public int CombatExperience { get; protected set; }
        private List<IVessel> vessels;
        public ICollection<IVessel> Vessels => vessels.AsReadOnly();
        public void AddVessel(IVessel vessel)
        {
            if (vessel == null)
            {
                throw new NullReferenceException(Utilities.Messages.ExceptionMessages.InvalidVesselForCaptain);
            }

            vessels.Add(vessel);
        }

        public void IncreaseCombatExperience()
        {
            CombatExperience += 10;
        }

        public string Report()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(
                $"{this.FullName} has {this.CombatExperience} combat experience and commands {vessels.Count} vessels.");

            if (vessels.Count > 0)
            {
                foreach (IVessel vessel in vessels)
                {
                    sb.AppendLine(vessel.ToString());
                }
            }

            return sb.ToString().Trim();
        }
    }
}
