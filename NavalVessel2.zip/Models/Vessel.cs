﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Xml;
using NavalVessels.Models.Contracts;

namespace NavalVessels.Models
{
    public abstract class Vessel : IVessel
    {
        public Vessel(string name, double mainWeaponCaliber, double speed, double armorThickness)
        {
            Name = name;
            MainWeaponCaliber = mainWeaponCaliber;
            Speed = speed;
            initialArmorThickness = armorThickness;
            ArmorThickness = armorThickness;
            targets = new List<string>();
        }

        private string name;
        private ICaptain captain;
        public string Name
        {
            get
            {
                return name;
            }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentNullException(Utilities.Messages.ExceptionMessages.InvalidVesselName);
                }

                name = value;
            }
        }
        public ICaptain Captain
        {
            get { return captain; }
            set
            {
                if (value == null)
                {
                    throw new NullReferenceException(Utilities.Messages.ExceptionMessages.InvalidCaptainToVessel);
                }

                captain = value;
            }
        }

        protected double initialArmorThickness;
        public double ArmorThickness { get; set; }
        public double MainWeaponCaliber { get; protected set; }
        public double Speed { get; protected set; }
        private List<string> targets;
        public ICollection<string> Targets => targets.AsReadOnly();
        public void Attack(IVessel target)
        {
            if (target == null)
            {
                throw new NullReferenceException(Utilities.Messages.ExceptionMessages.InvalidTarget);
            }

            captain.IncreaseCombatExperience();
            target.Captain.IncreaseCombatExperience();

            target.ArmorThickness -= this.MainWeaponCaliber;
            if (target.ArmorThickness < 0)
            {
                target.ArmorThickness = 0;
            }

            this.targets.Add(target.Name);
        }

        public virtual void RepairVessel()
        {
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"- {this.name}");
            sb.AppendLine($"* Type: {this.GetType().Name}");
            sb.AppendLine($"* Armor thickness: {this.ArmorThickness}");
            sb.AppendLine($"* Main weapon caliber: {this.MainWeaponCaliber}");
            sb.AppendLine($"* Speed: {this.Speed} knots");
            sb.AppendLine($"* Targets: {(Targets.Count == 0 ? "None" : String.Join(", ", Targets))}");

            return sb.ToString().Trim();
        }
    }
}
