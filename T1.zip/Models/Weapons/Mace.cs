﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace Heroes.Models.Weapons
{
    public class Mace : Weapon
    {
        public Mace(string name, int durability) : base(name, durability)
        {
            weaponDamage = 25;
        }
        
        public override int DoDamage()
        {
            Durability -= 1;
            return Durability == 0 ? 0 : weaponDamage;
        }
    }
}
