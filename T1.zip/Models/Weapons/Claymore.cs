﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Heroes.Models.Weapons
{
    public class Claymore : Weapon
    {
        public Claymore(string name, int durability) : base(name, durability)
        {
            weaponDamage = 20;
        }

        public override int DoDamage()
        {
            Durability -= 1;
            return Durability == 0 ? 0 : weaponDamage;
        }
    }
}
