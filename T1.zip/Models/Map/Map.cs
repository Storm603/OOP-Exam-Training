﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Heroes.Models.Contracts;
using Heroes.Models.Heroes;

namespace Heroes.Models.Map
{
    public class Map : IMap
    {
        public string Fight(ICollection<IHero> players)
        {
            List<IHero> knights = players.Where(x => x.GetType().Name == "Knight" && x.IsAlive).ToList();
            List<IHero> barbarians = players.Where(x => x.GetType().Name == "Barbarian" && x.IsAlive).ToList();

            while (true)
            {
                foreach (IHero knight in knights)
                {
                    foreach (IHero barbarian in barbarians)
                    {
                        barbarian.TakeDamage(knight.Weapon.DoDamage());
                    }
                }

                if (!barbarians.Any(x => x.IsAlive))
                {
                    break;
                }

                barbarians = barbarians.Where(x => x.IsAlive).ToList();

                foreach (IHero barbarian in barbarians)
                {
                    foreach (IHero knight in knights)
                    {
                        knight.TakeDamage(barbarian.Weapon.DoDamage());
                    }
                }

                if (!knights.Any(x => x.IsAlive))
                {
                    break;
                }

                knights = knights.Where(x => x.IsAlive).ToList();

            }

            if (!barbarians.Any(x => x.IsAlive))
            {
                return $"The knights took {knights.Count(x => !x.IsAlive)} casualties but won the battle.";
            }

            return $"The barbarians took {knights.Count(x => !x.IsAlive)} casualties but won the battle.";
        }
    }
}
