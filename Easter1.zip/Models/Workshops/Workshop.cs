﻿using System;
using System.Collections.Generic;
using System.Text;
using Easter.Models.Bunnies.Contracts;
using Easter.Models.Dyes.Contracts;
using Easter.Models.Eggs.Contracts;
using Easter.Models.Workshops.Contracts;

namespace Easter.Repositories
{
    public class Workshop : IWorkshop
    {
        public void Color(IEgg egg, IBunny bunny)
        {
            foreach (IDye bunnyDye in bunny.Dyes)
            {
                while (!bunnyDye.IsFinished() || bunny.Energy != 0)
                {
                    if (egg.IsDone())
                    {
                        return;
                    }
                    bunny.Work();
                    bunnyDye.Use();
                    egg.GetColored();
                }
            }
        }
    }
}
