﻿// ReSharper disable InconsistentNaming
// ReSharper disable FunctionNeverReturns

using CarRacing.Repositories;

namespace CarRacing.Core
{
    using System;
    using Contracts;
    using IO;
    using IO.Contracts;

    public class Engine : IEngine
    {
        private readonly IWriter writer;
        private readonly IReader reader;
        private readonly IController controller;

        public Engine()
        {
            this.writer = new Writer();
            this.reader = new Reader();
            this.controller = new Controller();
            CarRepository carRepository = new CarRepository();
            RacerRepository racerRepository = new RacerRepository();
        }

        public void Run()
        {
            while (true)
            {
                string[] input = reader.ReadLine().Split();

                if (input[0] == "Exit")
                {
                    Environment.Exit(0);
                }

                try
                {
                    string result = string.Empty;

                    if (input[0] == "AddCar")
                    {
                        string type = input[1];
                        string make = input[2];
                        string model = input[3];
                        string VIN = input[4];
                        int horsePower = int.Parse(input[5]);

                        if (type != "SuperCar" && type != "TunedCar")
                        {
                            throw new ArgumentException(Utilities.Messages.ExceptionMessages.InvalidCarType);
                        }

                        result = controller.AddCar(type, make, model, VIN, horsePower);
                    }
                    else if (input[0] == "AddRacer")
                    {
                        string type = input[1];
                        string username = input[2];
                        string carVIN = input[3];

                        if (type != "ProfessionalRacer" && type != "StreetRacer")
                        {
                            throw new ArgumentException(Utilities.Messages.ExceptionMessages.InvalidRacerType);
                        }

                        result = controller.AddRacer(type, username, carVIN);

                        if (result == "false")
                        {
                            throw new ArgumentException(Utilities.Messages.ExceptionMessages.CarCannotBeFound);
                        }
                    }
                    else if (input[0] == "BeginRace")
                    {
                        string racerOneUsername = input[1];
                        string racerTwoUsername = input[2];

                        result = controller.BeginRace(racerOneUsername, racerTwoUsername);
                        string[] split = result.Split();

                        if (split[0] == "false")
                        {
                            string username = split[1];
                            throw new ArgumentException(string.Format(Utilities.Messages.ExceptionMessages.RacerCannotBeFound, username));
                        }
                    }
                    else if (input[0] == "Report")
                    {
                        result = controller.Report();
                    }

                    writer.WriteLine(result);
                }
                catch (Exception ex)
                {
                    writer.WriteLine(ex.Message);
                    continue;
                }
            }
        }
    }
}
