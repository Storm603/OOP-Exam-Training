﻿using System;
using System.Collections.Generic;
using System.Text;
using CarRacing.Models.Maps.Contracts;
using CarRacing.Models.Racers.Contracts;

namespace CarRacing.Models.Maps
{
    public class Map : IMap
    {
        public string StartRace(IRacer racerOne, IRacer racerTwo)
        {
            if (racerOne.IsAvailable() == false && racerTwo.IsAvailable() == false)
            {
                return Utilities.Messages.OutputMessages.RaceCannotBeCompleted;
            }
            else if (racerOne.IsAvailable() == true && racerTwo.IsAvailable() == false)
            {
                return String.Format(Utilities.Messages.OutputMessages.OneRacerIsNotAvailable, racerOne.Username, racerTwo.Username);
            }
            else if (racerOne.IsAvailable() == false && racerTwo.IsAvailable() == true)
            {
                return string.Format(Utilities.Messages.OutputMessages.OneRacerIsNotAvailable, racerTwo.Username, racerOne.Username);
            }

            
            double racerOneChanceForWinning = racerOne.Car.HorsePower * racerOne.DrivingExperience *
                                              (racerOne.RacingBehavior == "strict" ? 1.2 : 1.1);
            double racerTwoChanceForWinning = racerTwo.Car.HorsePower * racerTwo.DrivingExperience *
                                              (racerTwo.RacingBehavior == "strict" ? 1.2 : 1.1);
            racerOne.Race();
            racerTwo.Race();
            if (racerOneChanceForWinning > racerTwoChanceForWinning)
            {
                return string.Format(Utilities.Messages.OutputMessages.RacerWinsRace, racerOne.Username, racerTwo.Username, racerOne.Username);
            }
            return string.Format(Utilities.Messages.OutputMessages.RacerWinsRace, racerOne.Username, racerTwo.Username, racerTwo.Username);

        }
    }
}
