﻿using System;
using System.Collections.Generic;
using System.Text;
using CarRacing.Models.Cars.Contracts;
using CarRacing.Models.Racers.Contracts;

namespace CarRacing.Models.Racers
{
    public abstract class Racer : IRacer
    {
        private string username;
        private string racingBehaviour;
        private int drivingExperience;
        private ICar car;

        public Racer(string username, string racingBehaviour, int drivingExperience, ICar car)
        {
            Username = username;
            RacingBehavior = racingBehaviour;
            DrivingExperience = drivingExperience;
            Car = car;
        }
        public string Username
        {
            get { return username; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(Utilities.Messages.ExceptionMessages.InvalidRacerName);
                }

                username = value;
            }
        }
        public string RacingBehavior
        {
            get { return racingBehaviour; }
            private set
            {
                if (string.IsNullOrWhiteSpace(value))
                {
                    throw new ArgumentException(Utilities.Messages.ExceptionMessages.InvalidRacerBehavior);
                }

                racingBehaviour = value;
            }
        }
        public int DrivingExperience {
            get { return drivingExperience; }
            private set
            {
                if (value < 0 || value > 100)
                {
                    throw new ArgumentException(Utilities.Messages.ExceptionMessages.InvalidRacerDrivingExperience);
                }

                drivingExperience = value;
            }
        }
        public ICar Car
        {
            get { return car; }
            private set
            {
                if (value == null)
                {
                    throw new ArgumentException(Utilities.Messages.ExceptionMessages.InvalidRacerCar);
                }

                car = value;
            }
        }
        public void Race()
        {
            car.Drive();
            if (this.GetType().Name == "ProfessionalRacer")
            {
                this.drivingExperience += 10;
            }
            else if (this.GetType().Name == "StreetRacer")
            {
                this.drivingExperience += 5;
            }
        }

        public bool IsAvailable()
        {
            if (this.car.FuelAvailable >= car.FuelConsumptionPerRace)
            {
                return true;
            }

            return false;
        }
    }
}
